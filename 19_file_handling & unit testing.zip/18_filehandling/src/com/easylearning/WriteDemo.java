package com.easylearning;

import java.io.DataOutputStream;
import java.io.FileNotFoundException;
import java.io.FileOutputStream;
import java.io.FileWriter;
import java.io.IOException;
import java.io.PrintWriter;

public class WriteDemo {
	
	public static void exp1(String filename) {
		FileOutputStream fos=null;
		
		try {
			fos = new FileOutputStream(filename);
			byte[] arr=new byte[] {65,66,67,68};
			fos.write(arr);
		} catch (IOException e) {
			e.printStackTrace();
		}finally {
			if(fos!=null) {
				try {
					fos.close();
				} catch (IOException e) {
					// TODO Auto-generated catch block
					e.printStackTrace();
				}
			}
		}
	}
	
	
	public static void exp2(String filename) {
		
		
		try(FileOutputStream fos = new FileOutputStream(filename,true)) {
			
			for(int i=65;i<=90;i++) {
				fos.write(i);
			}
		} catch (IOException e) {
			e.printStackTrace();
		}
	}
	
	public static void exp3(String filename) {
		try(FileOutputStream fos = new FileOutputStream(filename,true);
				DataOutputStream dos= new DataOutputStream(fos);){
			//dos.writeUTF("this is demo of dataoutput stream.55");
			
			
			
		} catch (FileNotFoundException e) {
			// TODO Auto-generated catch block
			e.printStackTrace();
		} catch (IOException e) {
			// TODO Auto-generated catch block
			e.printStackTrace();
		}
	}
	
	public static void exp4(String filename) {
		
		try(FileWriter fw=new FileWriter(filename)){
			fw.write("this is the first demo".toCharArray());
			
		} catch (IOException e) {
			// TODO Auto-generated catch block
			e.printStackTrace();
		}
	}
	
	public static void exp5(String filename) {
		try(PrintWriter out = new PrintWriter(filename)){
			out.println("This is the PrintWriter example");
		} catch (FileNotFoundException e) {
			// TODO Auto-generated catch block
			e.printStackTrace();
		}
	}
	
	public static void main(String[] args) {
		exp5("file3.txt");
		System.out.println("done");
	}

}
