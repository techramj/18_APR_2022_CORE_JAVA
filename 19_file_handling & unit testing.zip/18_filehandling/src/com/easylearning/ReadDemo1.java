package com.easylearning;

import java.io.BufferedReader;
import java.io.DataInputStream;
import java.io.FileInputStream;
import java.io.FileNotFoundException;
import java.io.FileReader;
import java.io.IOException;
import java.io.InputStreamReader;

public class ReadDemo1 {

	public static void exp1(String filename) {
		FileInputStream fis = null;
		try {
			fis = new FileInputStream(filename);
			int x = fis.read();
			while (x != -1) {
				System.out.print((char) x);
				x = fis.read();
			}
		} catch (FileNotFoundException e) {
			e.printStackTrace();
		} catch (IOException e) {
			e.printStackTrace();
		} finally {
			if (fis != null) {
				try {
					fis.close();
				} catch (IOException e) {
					e.printStackTrace();
				}
			}
		}
	}

	public static void exp2(String filename) {
		try (FileInputStream fis = new FileInputStream(filename)) {
			int x = fis.read();
			while (x != -1) {
				System.out.print((char) x);
				x = fis.read();
				Thread.sleep(10);
			}
		} catch (FileNotFoundException e) {
			e.printStackTrace();
		} catch (IOException e) {
			e.printStackTrace();
		} catch (InterruptedException e) {
			// TODO Auto-generated catch block
			e.printStackTrace();
		}
	}

	public static void exp3(String filename) {
		try (FileInputStream fis = new FileInputStream(filename); DataInputStream dis = new DataInputStream(fis);) {

			String str = dis.readLine();
			while (str != null) {
				System.out.println(str);
				str = dis.readLine();
				Thread.sleep(100);
			}

		} catch (FileNotFoundException e) {
			e.printStackTrace();
		} catch (IOException e) {
			e.printStackTrace();
		} catch (InterruptedException e) {
			// TODO Auto-generated catch block
			e.printStackTrace();
		}
	}

	public static void exp4(String filename) {
		try (FileReader fr = new FileReader(filename);) {
			int x = fr.read();
			while (x != -1) {
				System.out.print((char) x);
				x = fr.read();
				Thread.sleep(100);
			}

		} catch (FileNotFoundException e) {
			e.printStackTrace();
		} catch (IOException e) {
			e.printStackTrace();
		} catch (InterruptedException e) {
			e.printStackTrace();
		}
	}
	
	
	public static void exp5(String filename) {
		
		try (FileReader fr = new FileReader(filename);
				BufferedReader br=new BufferedReader(fr);) {
			String str=br.readLine();
			while (str != null) {
				System.out.print(str);
				str=br.readLine();
				Thread.sleep(100);
			}

		} catch (FileNotFoundException e) {
			e.printStackTrace();
		} catch (IOException e) {
			e.printStackTrace();
		} catch (InterruptedException e) {
			e.printStackTrace();
		}
	}
	
	
public static void exp6(String filename) {
		
		try (BufferedReader br=new BufferedReader(new InputStreamReader(new FileInputStream(filename)));) {
			String str=null;
			while ((str=br.readLine()) != null) {
				System.out.println(str);
				Thread.sleep(100);
			}

		} catch (FileNotFoundException e) {
			e.printStackTrace();
		} catch (IOException e) {
			e.printStackTrace();
		} catch (InterruptedException e) {
			e.printStackTrace();
		}
	}
	

	public static void main(String[] args) {

		String filename = "D:\\Ram\\classes\\workspace\\18_Apr_22_core_java\\18_filehandling\\src\\com\\easylearning\\ReadDemo1.java";

		exp6(filename);
	}

}
