import java.io.BufferedInputStream;
import java.io.BufferedReader;
import java.io.Console;
import java.io.DataInputStream;
import java.io.FileNotFoundException;
import java.io.IOException;
import java.io.InputStreamReader;
import java.io.RandomAccessFile;
import java.util.HashSet;
import java.util.Scanner;

public class ConosleDemo {

	public static void exp1() {
		try (DataInputStream dis = new DataInputStream(System.in)) {
			System.out.println("enter the string");
			String message = dis.readLine();
			System.out.println(message);

		} catch (IOException e) {

			e.printStackTrace();
		}
	}

	public static void exp2() {
		try (DataInputStream dis = new DataInputStream(System.in)) {
			System.out.println("enter number1: ");
			String str1 = dis.readLine();

			System.out.println("enter number2: ");
			String str2 = dis.readLine();

			int res = Integer.parseInt(str1) + Integer.parseInt(str2);
			System.out.println(res);

		} catch (IOException e) {

			e.printStackTrace();
		}
	}

	public static void exp3() {

		try (BufferedReader br = new BufferedReader(new InputStreamReader(System.in))) {
			System.out.println("enter number1: ");
			String str1 = br.readLine();

			System.out.println("enter number2: ");
			String str2 = br.readLine();

			int res = Integer.parseInt(str1) + Integer.parseInt(str2);
			System.out.println(res);

		} catch (IOException e) {

			e.printStackTrace();
		}
	}

	public static void exp4() {
		Scanner sc = new Scanner(System.in);
		System.out.println("enter number1: ");
		int x = sc.nextInt();

		System.out.println("enter number2: ");
		int y = sc.nextInt();

		System.out.println("result: " + (x + y));

	}

	public static void exp5() {
		Console console = System.console();
		System.out.println("enter name: ");
		String name = console.readLine();
		char[] password = console.readPassword("enter password: ");

		System.out.println("Name: " + name);
		System.out.println("Password: " + String.valueOf(password));
	}

	public static void main(String[] args) {

		exp5();
	}

	public static void exp6() {
		try {
			RandomAccessFile raf = new RandomAccessFile("a.txt", "rw");
		} catch (FileNotFoundException e) {
			// TODO Auto-generated catch block
			e.printStackTrace();
		}

	}

	

	

}
