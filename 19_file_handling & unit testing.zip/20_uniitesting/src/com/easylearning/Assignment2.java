package com.easylearning;

public class Assignment2 {
	
	public static void main(String[] args) {
		
	}
	
	
	public static int getMax(int[] arr) { // Marks: 10
		// WAP to find the print highest and lowest number in an array, without sorting
		int min = arr[0];
		int max = arr[0];
		int i = 0;
		int l = arr.length;
		for (i = 1; i <= l - 1; i++) {
			if (arr[i] >= max) {
				max = arr[i];
			}
		}
		
		return max;

	}
	
	public static int getSecondHighest(int[] arr) {
		if(arr==null || arr.length<2) {
			throw new IllegalArgumentException("Size should be greater than 2");
		}
		
		int max=0;
		int secondHighest = 0;
		
		if(arr[0]>arr[1]) {
			max=arr[0];
			secondHighest =arr[1];
		}else {
			max=arr[1];
			secondHighest =arr[0];
		}
		

		for (int i = 2; i <arr.length; i++) {
			if(arr[i]>max) {
				secondHighest = max;
				max= arr[i];
			}else if(arr[i]< max && arr[i]>secondHighest) {
				secondHighest = arr[i];
			}
		}
		
		return secondHighest;
		
	}

}
