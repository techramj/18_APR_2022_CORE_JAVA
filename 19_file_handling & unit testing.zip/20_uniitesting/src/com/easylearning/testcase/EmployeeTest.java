package com.easylearning.testcase;

import static org.junit.Assert.assertEquals;
import static org.junit.Assert.assertNotNull;

import org.junit.Before;
import org.junit.Test;

import com.easylearning.Employee;
import com.easylearning.Project;

public class EmployeeTest {
	
	private Employee emp;
	
	@Before
	public void before() {
		emp = new Employee(1, "Jack", 10000.0);
		emp.addSkill("C Prog", 4);
		emp.addSkill("Java", 10);
		emp.addSkill("Spring", 6);
		emp.addSkill("PLSQL", 10);
		
		Project project1 = new Project(1001,"EMS",emp);
		Project project2 = new Project(1002,"Social Automation",null);
		
		emp.addProject(project1);
		emp.addProject(project2);
	}
	
	
	@Test
	public void skillsTest() {
		Employee emp= new Employee();
		assertNotNull(emp.getSkills());
		assertEquals(0, emp.getSkills().size());
		
		emp.addSkill("Java", 10);
		assertEquals(1, emp.getSkills().size());
		
		emp.addSkill("Java", 11);
		assertEquals(1, emp.getSkills().size());
	}
	
	
	@Test
	public void removeProjectTest() {
		assertEquals(2, emp.getProjects().size());
		Project project = new Project(1002,"Social Automation",null);
		emp.removeProject(project);
		assertEquals(1, emp.getProjects().size());
	}
	
	@Test
	public void removeProjectTest1() {
		assertEquals(2, emp.getProjects().size());
		emp.removeProject(1001);
		assertEquals(1, emp.getProjects().size());
	}
	
	@Test
	public void removeProjectTest2() {
		assertEquals(2, emp.getProjects().size());
		emp.removeProject(10010);
		assertEquals(2, emp.getProjects().size());
	}
	
	

}
