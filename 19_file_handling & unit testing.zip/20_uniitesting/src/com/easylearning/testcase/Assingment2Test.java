package com.easylearning.testcase;

import static org.junit.Assert.assertEquals;

import org.junit.After;
//import org.junit.AfterClass;
import org.junit.Before;
//import org.junit.BeforeClass;
import org.junit.Test;

import com.easylearning.Assignment2;

public class Assingment2Test {
	
	@Test
	public void getMaxTest1() {
		int[] arr = new int[] {10,12,13,4};
		int res = Assignment2.getMax(arr);
		assertEquals(13, res);  //(expected, actual)
		
	}
	
	@Test
	public void getMaxTest2() {
		int[] arr = new int[] {10};
		int res = Assignment2.getMax(arr);
		assertEquals(10, res);  //(expected, actual)
	}
	
	@Test
	public void getMaxTest3() {
		int[] arr = new int[] {10,10,10};
		int res = Assignment2.getMax(arr);
		assertEquals(10, res);  //(expected, actual)
	}
	
	@Test
	public void getSecondHighestTest1() {
		int[] arr = new int[] {10,12,13,4};
		int res =Assignment2.getSecondHighest(arr);
		assertEquals(4, arr.length);
		assertEquals(12, res);
		
	}
	
	@Test
	public void getSecondHighestTest2() {
		int[] arr = new int[] {2,1};
		int res =Assignment2.getSecondHighest(arr);
		assertEquals(1, res);
		
	}
	
	@Test
	public void getSecondHighestTest3() {
		int[] arr = new int[] {2,1,9,8,8};
		int res =Assignment2.getSecondHighest(arr);
		assertEquals(8, res);
		
	}
	
	@Test(expected = IllegalArgumentException.class)
	public void testSecondHighestWithNoElementTest() {
		int[] arr = new int[] {};
		Assignment2.getSecondHighest(arr);
	}
	
	@Test(expected = IllegalArgumentException.class)
	public void testSecondHighestWithOneElementTest() {
		int[] arr = new int[] {1};
		Assignment2.getSecondHighest(arr);
	}
	
	@Test(expected = IllegalArgumentException.class)
	public void testSecondHighestWithNullTest() {
		int[] arr =null;
		Assignment2.getSecondHighest(arr);
	}
	
	
	
	
	

}
