import java.util.Arrays;
import java.util.HashMap;

public class Test {

	public static boolean isCyclicSubstring(String str, String substr) {

		boolean b = (str + str).contains(substr);
		System.out.println(substr + " = " + b);
		return b;
	}

	public static boolean isCyclicString(String sub, boolean ignoreCase) {
		String str = "ABCDEFGHIJKLMNOPQRSTUVWXYZ";
		String newStr = str + str;
		if (ignoreCase) {
			return newStr.toLowerCase().contains(sub.toLowerCase());
		} else {
			return newStr.contains(sub) || newStr.toLowerCase().contains(sub);
		}
	}

	private static HashMap<Integer, Integer> fibbMap = new HashMap<Integer, Integer>();

	public static int fibonacci(int n) {
		Integer val = fibbMap.get(n);
		if (val != null) {
			return val;
		}
		int x = 0;
		if (n == 0 || n == 1) {
			x = 1;
			fibbMap.put(n, x);
			return x;
		} else {
			x = fibonacci(n - 1) + fibonacci(n - 2);
			fibbMap.put(n, x);
			return x;
		}
	}

	public static int sum_of_digit(int n) {
		if (n < 10) {
			return n;
		} else {
			return (n % 10 + sum_of_digit(n / 10));
		}
	}

	public static int factorial(int n) {
		if (n == 1 || n == 0) {
			return 1;
		} else {
			return n * factorial(n - 1);
		}
	}

	public static void reverseString(StringBuilder sb, int x) {
		
		int endIndex = sb.length() - x;
		String s1 = sb.substring(x-1, x );
		String s2 = sb.substring(endIndex, endIndex + 1);
		System.out.println(s1);
		System.out.println(s2);
		
		sb.replace(x-1, x, s2);
		sb.replace(endIndex, endIndex + 1, s1);
		
		if(x == sb.length()/2) {
			return;
		}
		reverseString(sb, x+1);
		
	}

	public static void main(String[] args) {
		StringBuilder sb = new StringBuilder("apple");
		reverseString(sb,1);
		System.out.println(sb.toString());
	}
	
	//2 1 34 9 -2 8 7 3 10 30
	public static int findMaxDifference(int[] arr) {
		Arrays.sort(arr);
		return arr[arr.length-1]-arr[0];		
	}

}
