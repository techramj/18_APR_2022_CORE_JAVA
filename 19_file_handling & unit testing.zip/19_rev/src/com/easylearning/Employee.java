package com.easylearning;

import java.util.HashMap;
import java.util.HashSet;
import java.util.Iterator;
import java.util.Map;
import java.util.Objects;
import java.util.Set;

public class Employee {

	private Integer id;
	private String name;
	private Double salary;
	private Set<Project> projects = new HashSet<>();
	private Map<String, Integer> skills = new HashMap<>();

	public Employee() {
	}
	
	public Employee(Integer id, String name, Double salary) {
		this.id = id;
		this.name = name;
		this.salary = salary;
	}

	public Employee(Integer id, String name, Double salary, Set<Project> projects, Map<String, Integer> skills) {
		super();
		this.id = id;
		this.name = name;
		this.salary = salary;
		this.projects.addAll(projects);
		this.skills.putAll(skills);
	}

	public Integer getId() {
		return id;
	}

	public void setId(Integer id) {
		this.id = id;
	}

	public String getName() {
		return name;
	}

	public void setName(String name) {
		this.name = name;
	}

	public Double getSalary() {
		return salary;
	}

	public void setSalary(Double salary) {
		this.salary = salary;
	}

	public Map<String, Integer> getSkills() {
		return skills;
	}

	public Set<Project> getProjects() {
		return projects;
	}

	public void addSkill(String skill, Integer yearOfExperience) {
		skills.put(skill, yearOfExperience);
	}

	public void addSkills(Map<String, Integer> skills) {
		skills.putAll(skills);
	}

	public void removeSkill(String skill) {
		skills.remove(skill);
	}

	public void clearSkills() {
		skills.clear();	
	}

	public void removeProject(Project project) {
		projects.remove(project);
	}

	public void removeProject(Integer projectId) {
		Iterator<Project> itr = projects.iterator();
		while(itr.hasNext()) {
			if(itr.next().getProjectId().equals(projectId)) {
				itr.remove();
			}
		}
	}

	public void removeProject(String projectName) {
		Iterator<Project> itr = projects.iterator();
		while(itr.hasNext()) {
			if(itr.next().getProjectName().equalsIgnoreCase(projectName)) {
				itr.remove();
			}
		}
	}
	
	public void addProject(Project project) {
		projects.add(project);
	}
	
	public void removeAllProject() {
		projects.clear();
	}

	@Override
	public String toString() {
		StringBuilder empDetails = new StringBuilder();
		empDetails.append("Id: "+id);
		empDetails.append("\nName: "+name);
		empDetails.append("\nSalary: "+salary);
		empDetails.append("\n\nProjects: ");
		for(Project project: projects) {
			if(project!=null) {
				empDetails.append("\n"+project.toString());
			}
		}
		
		empDetails.append("\n\nSkills: ");
		for(String skill:skills.keySet()) {
			empDetails.append("\n"+skill);
		}
		return empDetails.toString();
	}

	@Override
	public int hashCode() {
		return Objects.hash(id, name, projects, salary, skills);
	}

	@Override
	public boolean equals(Object obj) {
		if (this == obj)
			return true;
		if (obj == null)
			return false;
		if (getClass() != obj.getClass())
			return false;
		Employee other = (Employee) obj;
		return Objects.equals(id, other.id);
	}

	
	
	
	
	
	

}
