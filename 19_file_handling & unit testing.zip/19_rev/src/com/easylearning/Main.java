package com.easylearning;

import java.util.HashMap;
import java.util.Map;
import java.util.Set;

public class Main {
	
	public static void main(String[] args) {
		Employee ram = new Employee(1,"Ram",10000.0);
		
		ram.addSkill("C Prog", 4);
		ram.addSkill("Java", 10);
		ram.addSkill("Spring", 6);
		ram.addSkill("PLSQL", 10);
		
		Project project1 = new Project(1001,"EMS",ram);
		Project project2 = new Project(1002,"Social Automation",null);
		
		ram.addProject(project1);
		ram.addProject(project2);
		
		
		System.out.println(ram);
		
		ram.addSkill("PLSQL", 11);
		
		System.out.println("-----------------------");
		System.out.println(ram);
		
		Project project3 = new Project(1002,"Social Automation",null);
		ram.addProject(project3);
		System.out.println("-----------------------");
		System.out.println(ram);
		
	}
	
	

}
