
public class Main {

	public static void main(String[] args) {

		Employee jack = new Employee(1, "Jack", 1000);

		/*for (int i = 2; i <= 999999; i++) {
			jack = new Employee(i, "jack-"+i, i*1000);
		}*/

		// System.gc(); //request to gc to collect the unwanted object or object with
		// zero reference

		System.out.println("Net salary: " + jack.calculateNetSalary());

		System.out.println(jack);

	}

}
