
public class Date {

	private int dd;
	private int mm;
	private int yy;
	
	public Date() {
		
	}

	public Date(int dd, int mm, int yy) {
		this.dd = dd;
		this.mm = mm;
		this.yy = yy;
	}

	public int getDd() {
		return dd;
	}

	public void setDd(int dd) {
		this.dd = dd;
	}

	public int getMm() {
		return mm;
	}

	public void setMm(int mm) {
		this.mm = mm;
	}

	public int getYy() {
		return yy;
	}

	public void setYy(int yy) {
		this.yy = yy;
	}
	
	
	//validation if dd,mm,yy is invalid then set the default value 
	// dd=1  mm=1, yy=2001
	
	//31,4,2019  => 1,4,2019
	//29,2,2001
	
	public boolean isLeapYear() {
		
		return true;
	}
	
	public int lastDayOfMonth() {
		return 30;
	}
	
}
