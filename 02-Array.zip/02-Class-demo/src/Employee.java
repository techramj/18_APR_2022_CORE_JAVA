
public class Employee {

	private int id;
	private String name;
	private double basicSalary;
	private double hra; // hra will be 40% of bs

	public Employee() {
	}

	public Employee(int id, String name, double salary) {
		this.id = id;
		this.name = name;
		this.basicSalary = salary;
		this.hra = .4 * salary;
	}

	public int getId() {
		return id;
	}

	public void setId(int id) {
		this.id = id;
	}

	public String getName() {
		return name;
	}

	public void setName(String name) {
		this.name = name;
	}

	public double getBasicSalary() {
		return basicSalary;
	}

	public void setBasicSalary(double basicSalary) {
		this.basicSalary = basicSalary;
		this.hra = .4 * basicSalary;
	}

	public double getHra() {
		return hra;
	}
	
	public double calculateNetSalary() {
		return basicSalary + hra;
	}
	
	public void finalize() {
		System.out.println("your last wish fullfilled");
	}
	
	public String toString() {
		return "id: "+id+"\nname: "+name+"\nbasic salary: "+basicSalary+" \nhra:"+hra;
	}

}
