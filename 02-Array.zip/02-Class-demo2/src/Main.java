
public class Main {

	public static void main(String[] args) {
	
		int a=10;
		int b=20;
		
		System.out.println("a="+a+"    b="+b);
		//add(a,b);
		a =a+b-(b=a);
		System.out.println("a="+a+"    b="+b);
		
		Employee e1 = new Employee(1,"Jack",1000);
		Employee e2 = new Employee(2,"john",2000);
		swap(e1,e2);
		System.out.println("value of e1 is\n"+e1+"\n------------------------------");
		System.out.println("value of e2 is\n"+e2+"\n------------------------------");
	}
	
	public static void swap(Employee e1, Employee e2) {
		int tempId = e1.getId();
		e1.setId(e2.getId());
		e2.setId(tempId);
		
		String tempName = e1.getName();
		e1.setName(e2.getName());
		e2.setName(tempName);
		
		double tempSal = e1.getBasicSalary();
		e1.setBasicSalary(e2.getBasicSalary());
		e2.setBasicSalary(tempSal);
	}
	
	public static void add(int a,int b) {
		int temp=a;
		a = b;
		b = temp;
	}

}
