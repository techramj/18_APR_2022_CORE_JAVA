Array: collection of data or similar type.
       memory is allocated continiously
       access throught the index
       
 In Java:
	 Array is an object
	 Array is a first class object
	 

Declare
int[] arr;
int arr[];

int[][] arr;