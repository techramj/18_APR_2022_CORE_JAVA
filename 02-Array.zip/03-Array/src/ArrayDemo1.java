
public class ArrayDemo1 {
	
	public static void main(String[] args) {
		//declare array in java
		int[] arr;
		arr = new int[5];
		
		int barr[] =new int[4];
		
		int[] carr = {1,2,3,4,20,30};  //so, array is called as first object obuject
		
		int[] darr;
		darr =new int[]{2,4,6,8,10,12,14};
		
		displayArray(arr);
		displayArray(barr);
		displayArray(carr);
		displayArray(darr);
		
		arr=darr;
		displayArray(arr);
		
	}
	
	public static void displayArray(int[] arr) {
		for(int var: arr) {
			System.out.print(var+"   ");
		}
		System.out.println();
	}
	
	
	public static void displayArray1(int[] arr) {
		for(int i=0;i<arr.length;i++) {
			System.out.print(arr[i]+"   ");
		}
		System.out.println();
	}

}
