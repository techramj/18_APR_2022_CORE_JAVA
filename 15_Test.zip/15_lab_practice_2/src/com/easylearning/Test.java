package com.easylearning;

//Total marks: 100
public class Test {
	
	public static void statementProblem1(int[] arr) {  //Marks: 10
		//WAP to find the print highest and lowest number in an array, without sorting
		
	}
	
	public static void statementProblem2(int[] arr) {  //Marks: 10
		//WAP to find the second highest number without sorting
	}
	
	public static void statementProblem3(int[] arr) {  //Marks: 10
		//the array contain number between 1 to 100.
		//WAP to find the number having the maximum occurrence
		//eg If array contain the following number: 2 3 4 2 2 4 5 6 3 3 11 22 1 22 33 44 2 2 2
		//output is 2.  no of occurence of 2 = 6
	}
	
	
	public static void statementProblem4(int[] arr) {  //Marks: 10
		//WAP to find whether the element is duplicate or not
		//in array 1 3 4 5 6 8 . output will be false
		//In array 1 3 2 4 5 6 1. output will be true as 1 s repeated 2 time
	}
	
	public static void statementProblem5(int[] arr) {  //Marks: 15
		//print the below pattern
		/*

   A
  B D
 E G I
J L N P
 Q S U
  V X
   Y
		 */
	}
	
	public static void statementProblem6(int[] arr) {  //Marks: 10
		//selection sort algorithm
	}
	
	public static void statementProblem7(int[] arr) {  //Marks: 10
		//insertion sort algorithm
	}
	
	
  /*  //Marks: 25
   * write a class Account.
Add one class variable minimum balance.
Add two method deposit and withdraw
Add two user define exception
1. MinimumBalanceException => the balance should be less than minimum balance.
2. MaxAmountDepositException => the max amount in a single deposit should not exceed 500000.
   */
	

}
