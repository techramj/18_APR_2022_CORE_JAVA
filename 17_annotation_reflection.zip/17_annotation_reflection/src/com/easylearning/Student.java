package com.easylearning;

public class Student {

}
