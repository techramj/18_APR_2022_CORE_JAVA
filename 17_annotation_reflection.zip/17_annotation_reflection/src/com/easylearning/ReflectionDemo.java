package com.easylearning;

import java.lang.annotation.Annotation;
import java.lang.reflect.Field;
import java.lang.reflect.Method;
import java.lang.reflect.Modifier;
import java.lang.reflect.Type;

public class ReflectionDemo {
	
	public static void main(String[] args) throws ClassNotFoundException {
		Class clazz = Class.forName("com.easylearning.Employee");
		
		Class clazz1 = Employee.class;
		
		//variable
		Field[] fields = clazz.getDeclaredFields();
		
		for(Field f: fields) {
			int m =f.getModifiers();
			System.out.print(Modifier.toString(m)+" ");
			System.out.print(f.getType().getName()+" ");
			System.out.println(f.getName());
		}
		
		//Methods
		System.out.println("\nMethods Details");
		Method[] methods = clazz.getDeclaredMethods();
		for(Method f:methods) {
			int m =f.getModifiers();
			System.out.print(Modifier.toString(m)+" ");
			System.out.print(f.getReturnType().getName()+" ");
			System.out.print(f.getName());
			Type[] types = f.getGenericParameterTypes();
			System.out.print("(");
			for(Type t:types) {
				System.out.print(t.getTypeName()+",");
			}
			System.out.println(")");
			
			//annotation
			Annotation[] annotations = f.getDeclaredAnnotations();
			for(Annotation a:annotations) {
				System.out.println(a.toString());
			}
			System.out.println("_________________________________________________________");
		}
		
		
		
	}

}
