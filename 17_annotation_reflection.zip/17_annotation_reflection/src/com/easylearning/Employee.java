package com.easylearning;

import java.util.ArrayList;
import java.util.List;

/**
 * @author Ram Jaiswal
 *
 */
public class Employee {

	@MyAnno(message="Unique Identifier")
	private Integer id;
	String name;
	protected Double salary;
	public String project;
	 

	
	@MyAnno(message="default constructor")
	@ConstuctAnno("default constructor")
	public Employee() {
	
	}

	
	public Employee(Integer id, String name, Double salary) {
		super();
		this.id = id;
		this.name = name;
		this.salary = salary;
	}

	public Integer getId() {
		return id;
	}

	@ConstuctAnno
	public void setId(Integer id) {
		this.id = id;
	}

	public String getName() {
		return name;
	}

	public void setName(String name) {
		this.name = name;
	}

	public Double getSalary() {
		return salary;
	}

	public void setSalary(Double salary) {
		this.salary = salary;
	}
	
	
	@Deprecated
	public void display() {
		System.out.println("id=" + id + ", name=" + name + ", salary=" + salary);
	}

	@Override
	public String toString() {
		return "Employee [id=" + id + ", name=" + name + ", salary=" + salary + "]";
	}
	
	/**
	 * @return net salary
	 */
	@MyAnno(message="calculating net salary")
	public double computeSalary() {
		return salary;
	}
	
	/**
	 * This is to demonstrate the java docs
	 * @param a int a it a dummy method parameter
	 */
	@SuppressWarnings({ "unused", "rawtypes" })
	public void foo(int a) {
		//@SuppressWarnings("unused")
		int b;
		//@SuppressWarnings("unused")
		int c;
		
		//@SuppressWarnings("rawtypes")
		List list= new ArrayList();
		
		System.out.println(list);
	}
	
	
	public static int noOfMethod(String className,String packageName) {
		return 0;
	}

}
