package com.easylearning;

import com.easylearning.exception.InSufficientBalanaceException;

public class Account {

	private Integer accountId;
	private double balance;

	public Account() {
		// TODO Auto-generated constructor stub
	}

	public Account(Integer accountId, double balance) {
		super();
		this.accountId = accountId;
		this.balance = balance;
	}

	public Integer getAccountId() {
		return accountId;
	}

	public void setAccountId(Integer accountId) {
		this.accountId = accountId;
	}

	public double getBalance() {
		return balance;
	}

	public void setBalance(double balance) {
		this.balance = balance;
	}

	public void deposit(double amount) {
		balance += amount;
		System.out.println("amount deposited successfully");
	}

	public void withdraw(double amount) throws InSufficientBalanaceException {
		try {
		if(balance<amount) {
			throw new InSufficientBalanaceException("Insufficient balance. Balance:"+balance);
		}
		balance = balance - amount;
		System.out.println("amount withdrawn successfully");
	   }finally {
		   System.out.println("finally blocked called");
	   }
	}

}
