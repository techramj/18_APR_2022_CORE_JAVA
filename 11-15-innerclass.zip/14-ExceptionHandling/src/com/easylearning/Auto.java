package com.easylearning;

public class Auto implements AutoCloseable{
	
	public void display() {
		System.out.println("start.........");
		if(1==1) {
			throw new RuntimeException();
		}
		System.out.println("end...........");
	}

	@Override
	public void close() throws Exception {
		System.out.println("close method called....");
		
		
	}

}
