package com.easylearning;

import java.io.IOException;

public class Demo3 {
	
	
	public static void main(String[] args) {
		try(Auto a= new Auto()){
			System.out.println("try block");
			a.display();
		}catch(Exception e) {
			System.out.println("catch block");
		}
		
		
		int[] arr= new int[] {1,0,1,1,0,0,0,0,0,1,0};
		display(arr);
		arr=sort(arr);
		System.out.println("after sorting");
		display(arr);
		
	
		
	}
	
	public static int[] sort(int[] arr) {
		int length = arr.length;
		int count = 0;
		for(int a:arr) {
			if(a==0) {
				++count;
			}
		}
		arr = new int[length];
		for(int i=count;i<arr.length;i++) {
			arr[i]=1;
		}
		return arr;
	}
	
	public static void display(int[] arr) {
		for(int a:arr) {
			System.out.print(a+"  ");
		}
		System.out.println();
	}
	
}




//array. count even number and odd number in an array
//array=>  sort the array
//array has two number 0 and 1. sort the array.

//int[] arr= new int[] {1,0,1,1,0,0,0,1,1,1,0};
