package com.easylearning;

import com.easylearning.exception.InSufficientBalanaceException;

public class Demo2 {
	
	public static void main(String[] args)  {
		
	
		Account account = new Account(101, 10000);
		try {
			account.withdraw(2000);
			account.withdraw(2000);
			account.withdraw(9000);
			
			account.withdraw(9000);
			account.withdraw(9000);
		} catch (InSufficientBalanaceException e) {
			e.printStackTrace();
		}
		
		System.out.println("end");
		
	}

}
