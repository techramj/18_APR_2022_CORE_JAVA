package com.easylearning;

import java.io.FileInputStream;
import java.io.FileNotFoundException;
import java.io.IOException;

public class Demo1 {

	public static void exp1(String[] args) {
		try {
			int num1 = Integer.parseInt(args[0]);
			int num2 = Integer.parseInt(args[1]);

			int res = num1 / num2;
			System.out.println(res);
		} catch (ArrayIndexOutOfBoundsException exp) {
			System.out.println("enter the element!!!");
		} catch (NumberFormatException exp) {
			System.out.println("Only number is allowed");
		} catch (ArithmeticException exp) {
			System.out.println("cannot divide number by 0. Please eneter second element as non zero");
		}

		System.out.println("end");
	}

	public static void exp2(String[] args) {
		try {
			int num1 = Integer.parseInt(args[0]);
			int num2 = Integer.parseInt(args[1]);

			int res = num1 / num2;
			System.out.println(res);
		} catch (ArrayIndexOutOfBoundsException | NumberFormatException | ArithmeticException exp) {
			System.out.println("Only number is allowed");
		}

		System.out.println("end");
	}

	public static void errorsExp() {
		errorsExp();

	}

	public static void checkExpDemo() {
		// read a file
		String filename = "D:\\Ram\\classes\\workspace\\18_Apr_22_core_java\\14-ExceptionHandling\\src\\com\\easylearning\\Demo1.java";
		FileInputStream fis = null;
		try {
			fis = new FileInputStream(filename);
			int x = fis.read();
			while (x != -1) {
				System.out.print((char) x);
				x = fis.read();
				Thread.sleep(10);
			}
			fis.close();
		} catch (FileNotFoundException e) {
			System.out.println("invalid file name");
		} catch (IOException e) {
			System.out.println("cannot read file");
			try {
				fis.close();
			} catch (IOException e1) {
				// TODO Auto-generated catch block
				e1.printStackTrace();
			}
		} catch (InterruptedException e) {
			e.printStackTrace();
			try {
				fis.close();
			} catch (IOException e1) {
				// TODO Auto-generated catch block
				e1.printStackTrace();
			}
		}

	}

	public static void checkExpDemo1() {
		// read a file
		String filename = "D:\\Ram\\classes\\workspace\\18_Apr_22_core_java\\14-ExceptionHandling\\src\\com\\easylearning\\Demo1.java";
		FileInputStream fis = null;
		try {
			fis = new FileInputStream(filename);
			int x = fis.read();
			while (x != -1) {
				System.out.print((char) x);
				x = fis.read();
				Thread.sleep(10);
			}
		} catch (FileNotFoundException e) {
			System.out.println("invalid file name");
		} catch (IOException e) {
			System.out.println("cannot read file");

		} catch (InterruptedException e) {
			e.printStackTrace();
		} finally {
			try {
				if (fis != null) {
					fis.close();
				}
			} catch (IOException e1) {
				// TODO Auto-generated catch block
				e1.printStackTrace();
			}
		}

	}
	
	//ARM example: Introduced in Java 7
	public static void checkExpDemo2() {
		// read a file
		String filename = "D:\\Ram\\classes\\workspace\\18_Apr_22_core_java\\14-ExceptionHandling\\src\\com\\easylearning\\Demo1.java";
		
		try(FileInputStream fis = new FileInputStream(filename); ) {
			
			int x = fis.read();
			while (x != -1) {
				System.out.print((char) x);
				x = fis.read();
				Thread.sleep(10);
			}
		} catch (FileNotFoundException e) {
			System.out.println("invalid file name");
		} catch (IOException e) {
			System.out.println("cannot read file");

		} catch (InterruptedException e) {
			e.printStackTrace();
		}

	}

	public static boolean isPalindrome(String str) {

		// Pointers pointing to the beginning
		// and the end of the string
		int i = 0, j = str.length() - 1;

		// While there are characters to compare
		while (i < j) {

			// If there is a mismatch
			if (str.charAt(i) != str.charAt(j)) {
				return false;
			}
			i++;
			j--;
		}
		return true;
	}

	public static void main(String[] args) {
		// exp1(args);
		checkExpDemo();
	}

}
