package com.easylearning.exception;

public class InSufficientBalanaceException  extends Exception{
	
	public InSufficientBalanaceException() {
		// TODO Auto-generated constructor stub
	}
	
	
	public InSufficientBalanaceException(String message) {
		super(message);
	}
	
}
