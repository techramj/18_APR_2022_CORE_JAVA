package com.easylearning;

public class StringDemo1 {

	public static void exp1() {
		String str1 = "abc";
		String str2 = "abc";
		String str3 = new String("abc");

		str1 = str1.concat("xyz");

		System.out.println(str1);
		System.out.println(str1 == str2);
		System.out.println(str1 == str3);

		System.out.println(str1.equals(str3));

		String s = "abcdefgh";
		System.out.println(s.substring(3, 8));
		char[] arr = s.toCharArray();

	}

	public static void displayCountOfNumber(long l) {
		int[] arr = new int[10];
		while (l != 0) {
			arr[(int) l % 10]++;
			l = l / 10;
		}

		for (int i = 0; i < arr.length; i++) {
			if (arr[i] != 0) {
				System.out.println(i + "=" + arr[i]);
			}
		}
	}

	public static void exp2() {
		String str = "";

		for (int i = 65; i <= 90; i++) {
			str = str.concat((char) i + "");
		}
		System.out.println(str);
	}

	public static void exp3() {
		// StringBuffer and StringBuilder

		String str = "";
		
		StringBuilder sb = new StringBuilder(str);

		for (int i = 65; i <= 90; i++) {
			sb.append((char) i);
		}
		str = sb.toString();
		
		System.out.println(str);
		

	}

	public static boolean checkPalindrome(String str) {
		return str.equals(new StringBuilder(str).reverse().toString());
	}


	public static void main(String[] args) {
		exp3();
		System.out.println(checkPalindrome("malayalam"));
		System.out.println(checkPalindrome("Nitin"));
		System.out.println(checkPalindrome("abc"));
	}

}
