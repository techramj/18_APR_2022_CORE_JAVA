
public class Outer {
 
	private int id = 11;
	
	
	public class Inner{
		
		private int id=22;
		
		public void test() {
			int id = 33;
			System.out.println(Outer.this.id);
			System.out.println(this.id);
			System.out.println(id);
		}
	}
	
	
}



