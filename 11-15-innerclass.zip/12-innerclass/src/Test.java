
public class Test {
	
	public static void simpleInnerClassExp() {
		Outer outer = new Outer();
		Outer.Inner inner = outer.new Inner();
		inner.test();
		
		
		Outer.Inner inner1 = new Outer().new Inner();
		
	}
	
	public static void staticInnerClassExp() {
		Account.PassbookWriter writer = new Account.PassbookWriter();
		
	}
	
	public static void localInnerClassExp() {
		int a=10;
		class A{
			public void foo() {
				System.out.println("foo method");
			}
		} 
		A ob = new A();
		ob.foo();
		
		class B{}
	}
	
	public static void anoynomousInnerClassExp() {
		Dog d = new Dog();
		Dog dog = new Dog() {
			
			@Override
			public void bark() {
				System.out.println("bowwwwwwwwwwwwwwww");
			}
		};
		
		d.bark();
		dog.bark();
		
		System.out.println(d.getClass());
		System.out.println(dog.getClass());
	}
	
	public static void main(String[] args) {
		//simpleInnerClassExp();
		anoynomousInnerClassExp();
	}

}
