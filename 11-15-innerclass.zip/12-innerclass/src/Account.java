
public class Account {
	
	private int accountId;
	private static String bank;
	
	
	static class PassbookWriter{
		
		private int a=10;
		
		public void test() {
			System.out.println(bank);
			System.out.println(a);
		}
		
		public static void foo() {
			System.out.println(bank);
		}
	}
	
	

}


