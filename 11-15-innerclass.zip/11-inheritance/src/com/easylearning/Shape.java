package com.easylearning;

public abstract class Shape {
	
	public abstract double area();
	
	public abstract double peri();
	
	public void display() {
		System.out.println("Area: "+area());
		System.out.println("Perimeter: "+peri());
	}
	

}
