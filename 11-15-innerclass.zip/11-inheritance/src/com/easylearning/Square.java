package com.easylearning;

public class Square extends Rectangle{
	
	private int side;
	
	public Square() {
		// TODO Auto-generated constructor stub
	}

	public Square(int side) {
		super(side,side);
		this.side = side;
	}
	

}
