package com.easylearning;

public class Test {

	public static void main(String[] args) {
		A ob= new B();
		System.out.println(ob.getA());
		System.out.println(ob.a);  //dynamic  binding 
	}

}

class A {
	public int a = 1000;

	public int getA() {
		return a;
	}
	
	public final void foo() {
		System.out.println("foo class");
	}
}


final class B extends A {
	public int a = 5555;

	public  int getA() {
		return a;
	}
	
	
}

