package com.easylearning;

public class Circle extends Shape implements Printable {

	private double radius;
	private static final double PI = 3.14;

	public Circle() {
		// TODO Auto-generated constructor stub
	}

	public void setRadius(double radius) {
		this.radius = radius;
	}

	public Circle(double radius) {
		super();
		this.radius = radius;
	}

	@Override
	public double area() {
		return PI * radius * radius;
	}

	@Override
	public double peri() {

		return 2 * PI * radius;
	}

	@Override
	public void print() {
		System.out.println("Radius: "+radius);
		System.out.println("Area or circle: "+area());
		System.out.println("Perimeter of Circle: "+peri());
		
	}

}
