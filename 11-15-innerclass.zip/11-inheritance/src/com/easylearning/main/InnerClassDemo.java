package com.easylearning.main;

import com.easylearning.Printable;
import com.easylearning.Shape;

public class InnerClassDemo {
	
	public static void main(String[] args) {
		Shape shape = new Shape() {

			@Override
			public double area() {
				// TODO Auto-generated method stub
				return 0;
			}

			@Override
			public double peri() {
				// TODO Auto-generated method stub
				return 0;
			}};
	}
	
	Printable p= new Printable() {

		@Override
		public void print() {
			// TODO Auto-generated method stub
			
		}
		
	};
	
	

}
