package com.easylearning.main;

public class Dog {
	
	
	public void bark() {
		System.out.println("bow bow...");
	}
}
