package com.easylearning.main;

import com.easylearning.Circle;
import com.easylearning.Rectangle;
import com.easylearning.Shape;
import com.easylearning.Square;

public class AbstractDemo {
	public static void main(String[] args) {
		//Shape s = new Shape();    //cannot instantiate the abstract class
		
		Rectangle rect1 = new Rectangle(10,5);
		display(rect1);
		
		Rectangle rect2 = new Rectangle(10,5);
		display(rect2);
		
		
		
		Circle c = new Circle(5);
		display(c);
		
		display(new Square(20));
	}
	
	public static void display(Shape rectangle) {
		System.out.println("Area: "+rectangle.area());
		System.out.println("Peri: "+rectangle.peri());
		Main.printLine();
	}
	
	


}
