package com.easylearning.main;

import com.easylearning.Employee;
import com.easylearning.SalesPerson;
import com.easylearning.pkg1.Manager;

public class Main2 {

	public static void main(String[] args) {

		SalesPerson sp = new SalesPerson(1, "jack", 2000, 20000, 2); // tight coupling

		Employee emp1 = new SalesPerson(1, "jack", 2000, 20000, 2); // loose coupling

		Employee emp2 = new Employee(11, "John", 20000);
		
		Manager mgr= new Manager();

		display(emp1);
		display(emp2);
		display(mgr);
		// display(sp);

	}

	public static void display(Employee emp) {
		System.out.println(emp.getClass());
		System.out.println(emp);
		System.out.println("Net salary: " + emp.computeNetSalary());
		
		if(emp instanceof SalesPerson) {
			System.out.println("commission: " + ((SalesPerson) emp).computeCommission());
		}
		Main.printLine();
	}

	


}
