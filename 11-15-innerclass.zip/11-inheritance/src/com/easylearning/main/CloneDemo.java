package com.easylearning.main;

import com.easylearning.Bike;
import com.easylearning.Employee;
import com.easylearning.Engine;

public class CloneDemo {
	public static void main(String[] args) throws Exception {
			Engine engine = new Engine("300CC Engine");
			Bike bike =new Bike("RE", engine);
			
			Bike bike1 = bike.clone();
			System.out.println(bike == bike1);
			System.out.println(bike.getEngine() == bike1.getEngine());
			
			
			
	}

	public static void eg1() throws Exception {
		Employee emp = new Employee(1, "Jessica", 1000);

		Employee emp1 = emp.cloneObject();

		System.out.println(emp == emp1);
		System.out.println(emp.equals(emp1));
		System.out.println(emp);
		System.out.println(emp1);

		Employee emp2 = emp.clone();

		System.out.println(emp == emp2);
		System.out.println(emp.equals(emp2));
		
		
		
	}
	
	public static void printNumCount(long l) {
		l =99912333889911L;
		
	}
}


