package com.easylearning.main;

import com.easylearning.Circle;
import com.easylearning.Employee;
import com.easylearning.Printable;
import com.easylearning.Rectangle;
import com.easylearning.SalesPerson;

public class InterfaceDemo {

	public static void main(String[] args) {

		Printable p = null;

		Rectangle rect = new Rectangle(10, 20);
		Circle circle = new Circle(10);
		Employee emp1 = new Employee(1, "Jack", 10000);
		SalesPerson sp2 = new SalesPerson(2, "john", 3000, 40000, 2);
		
		print(circle);
		print(emp1);
		print(sp2);
	}

	public static void print(Printable p) {
		p.print();
	}

	
}






