package com.easylearning;

public class WrapperDemo {
	
	public static void exp1() {
		int a = 10;
		Integer iob = new Integer(10);   //primitive to Wrapper object
		Integer iob1  = Integer.valueOf(10); //primitive to Wrapper object
		
		int num = iob.intValue();  //wrapper object to primitive
		
		System.out.println(Integer.MIN_VALUE);
		System.out.println(Integer.toBinaryString(101111));
		
		
		String str="10";
		int x = Integer.parseInt(str);
	}
	
	
	public static void autoboxingExp() {
		
		int a=10;
		Integer b = Integer.valueOf(10);
		Integer c = Integer.valueOf(20);
		Integer res = Integer.valueOf( b.intValue() + c.intValue());
		
		//Autoboxing and unboxing
		Integer p = 10;
		Integer q = 20;
		Integer res1 = p+q;
		
		System.out.println(res1);
		
	}
	
	public static void main(String[] args) {
		
		autoboxingExp();
		
	}

}
