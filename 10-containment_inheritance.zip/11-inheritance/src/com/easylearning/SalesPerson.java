package com.easylearning;

public class SalesPerson extends Employee {

	private double sales;
	private double commission;

	public SalesPerson() {
		//System.out.println("default sp constructor called");
	}

	public SalesPerson(int id,String name, double salary,double sales, double commission) {
		super(id,name,salary);
		//System.out.println("paramterized SP contructor called");
		this.sales = sales;
		this.commission = commission;
	}

	public double getSales() {
		return sales;
	}

	public void setSales(double sales) {
		this.sales = sales;
	}

	public double getCommission() {
		return commission;
	}

	public void setCommission(double commission) {
		this.commission = commission;
	}

	
	
	public double computeCommission() {
		return sales * commission /100;
	}
	
	//Override
	public double computeNetSalary() {
		//System.out.println("inside Salesperson computeNetSalary");
		return super.computeNetSalary()+computeCommission();
	}

	@Override
	public String toString() {
		return  super.toString() + "    SalesPerson [sales=" + sales + ", commission=" + commission + "]";
	}
	
	

}
