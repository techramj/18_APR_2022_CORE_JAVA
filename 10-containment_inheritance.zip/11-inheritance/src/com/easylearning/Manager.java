package com.easylearning;

public class Manager extends Employee {

}
