package com.easylearning.main;

import com.easylearning.Employee;
import com.easylearning.SalesPerson;

public class Main {

	public static void main(String[] args) {

		Employee emp = new Employee(1, "Sam", 1000);
		System.out.println(emp);

		printLine();

		SalesPerson sp = new SalesPerson(2, "jack", 5000, 10000, 2);
		System.out.println(sp);

		printLine();

		int a = 10;
		int b = 10;
		
		System.out.println(a==b);
		
		Employee emp1 = new Employee(11, "Eleen", 50000);
		Employee emp2 = new Employee(11, "Eleena", 50000);
	
		
		System.out.println(emp1 == emp2);
		
		System.out.println(emp1.hashCode());
		System.out.println(emp2.hashCode());
		
		

	}

	public static void printLine() {
		System.out.println("--------------------------------------------");
		System.out.println();
	}

}
