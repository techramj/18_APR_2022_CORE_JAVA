package com.easylearning.model;

public class Math {

	public static void add1(int a, int b) {
		int res = a + b;
		System.out.println("int int = " + res);
	}

	public static void add(int a, int b, int c) {
		int res = a + b + c;
		System.out.println("int int int = " + res);
	}

	public static void add(float a, float b) {
		float res = a + b;
		System.out.println("float float = " + res);
	}

	public static void add(double a, double b) {
		double res = a + b;
		System.out.println("double double = " + res);
	}

	public static void add(long a, long b) {
		long res = a + b;
		System.out.println("long long = " + res);
	}
	
	public static void add(int a, int b,int...args) {
		int res =a+b;
		for(int arg:args) {
			res+=arg;
		}
		System.out.println("int...args: "+res);
	}
	
	public static void add(long...args) {}

}
