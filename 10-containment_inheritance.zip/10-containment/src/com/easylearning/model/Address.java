package com.easylearning.model;

public class Address {

	private String city;
	private String landmark;
	private String pincode;

	public Address() {
	}

	public Address(String city, String landmark, String pincode) {
		this.city = city;
		this.landmark = landmark;
		this.pincode = pincode;
	}

	public String getCity() {
		return city;
	}

	public void setCity(String city) {
		this.city = city;
	}

	public String getLandmark() {
		return landmark;
	}

	public void setLandmark(String landmark) {
		this.landmark = landmark;
	}

	public String getPincode() {
		return pincode;
	}

	public void setPincode(String pincode) {
		this.pincode = pincode;
	}

	@Override
	public String toString() {
		return "Address [city=" + city + ", landmark=" + landmark + ", pincode=" + pincode + "]";
	}

}
