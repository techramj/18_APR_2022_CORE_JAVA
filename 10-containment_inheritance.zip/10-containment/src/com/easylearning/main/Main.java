package com.easylearning.main;

import com.easylearning.model.Address;
import com.easylearning.model.Employee;
import static com.easylearning.model.Math.add;
import static java.lang.System.out;

public class Main {

	public static void main(String[] args) {
		overloadingDemo();
		
	}
	
	
	public static void overloadingDemo() {
		add(1, 2);
		add(1, 2,3);
		add(1, 2,3,4,5,6,7,8,9);
		
	    out.println();

	
		
	}

	public static void contianmentDemo() {
		// intialize via contructor
		Address add1 = new Address("Pune", "Near GT road", "411028");
		Employee emp1 = new Employee(1, "Jack", 1000, add1);

		// intialize via setter method
		Address add2 = new Address();
		add2.setCity("Pune");
		add2.setPincode("411018");
		add2.setLandmark("near SB road");

		Employee emp = new Employee();
		emp.setId(1);
		emp.setName("John");
		emp.setSalary(5000);
		emp.setMailAddress(add2);
		emp.setPermanenetAddress(add2);
	}

}
