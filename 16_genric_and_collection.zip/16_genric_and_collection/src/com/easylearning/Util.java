package com.easylearning;

import java.util.ArrayList;
import java.util.List;

public class Util {
	
	
	public static List<Employee> getEmpList(){
		List<Employee> list =new ArrayList<Employee>();
		
		Employee emp1 = new Employee(4, "John", 1000);
		Employee emp2 = new Employee(8, "Abel", 9000);
		Employee emp3 = new Employee(6, "Kochhar", 11000);
		Employee emp4 = new Employee(5, "King", 2000);
		Employee emp5 = new Employee(2, "Sam", 11000);
		Employee emp6 = new Employee(1, "Jessica", 9000);
		Employee emp7 = new Employee(9, "Maria", 5000);
		Employee emp8 = new Employee(3, "Jack", 10000);
		
		list.add(emp1);
		list.add(emp2);
		list.add(emp3);
		list.add(emp4);
		list.add(emp5);
		list.add(emp6);
		list.add(emp7);
		list.add(emp8);
		
		return list;
	}
	
	public static List<String> getStringList(){
		List<String> fruits =new ArrayList<String>();
		fruits.add("carrot");
		fruits.add("mango");
		fruits.add("grapes");
		fruits.add("guava");
		fruits.add("plum");
		fruits.add("apple");
		fruits.add("pineapple");
		fruits.add("apple");
		
		return fruits;
	}
	
	public static  List<Integer> getIntegerList(){
		List<Integer> list =new ArrayList<>();
		
		list.add(12);
		list.add(1);
		list.add(82);
		list.add(72);
		list.add(102);
		list.add(121);
		
		return list;
	}
	
	
	public static  List<Double> getDoubleList(){
		List<Double> list =new ArrayList<>();
		
		list.add(12.0);
		list.add(1.0);
		list.add(82.7);
		list.add(72.5);
		list.add(102.9);
		list.add(121.3);
		
		return list;
	}

}
