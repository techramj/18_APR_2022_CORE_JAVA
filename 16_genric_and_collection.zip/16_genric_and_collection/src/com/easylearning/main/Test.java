package com.easylearning.main;

import java.util.ArrayList;
import java.util.List;

import static com.easylearning.Util.*;

public class Test {

	
	public static void main(String[] args) {
		List<Integer> list = new ArrayList<>();
		list.add(1);
		list.add(2);
		list.add(3);
		list.add(4);
		
		System.out.println(list);
		list.remove(Integer.valueOf(2));
		
		System.out.println(list);
		
		List<Double> dlist = getDoubleList();
		List<String> slist = getStringList();
		List<Integer> ilist = getIntegerList();
		
		double x=calculateAvg(ilist);
		System.out.println(x);
		
		x=calculateAvg(dlist);
		System.out.println(x);
		//calculateAvg(slist);
		
		
		List<Integer> i1=null;
		List<Number> i2=null;
		List<Object> i3=null;
		
		foo(i1);
		foo(i2);
		foo(i3);
		
		
	}
	
	public static double calculateAvg(List<? extends Number> list) {
		double res=0;
		for(Number n:list) {
			res = res +n.doubleValue();
		}
		return res/list.size();
	}
	
	
	public static double foo(List<? super Integer> list) {
		list.add(1);
		
		return 0;
	}
	
	
	
}
