package com.easylearning.main;

import com.easylearning.General;
import com.easylearning.Generic;

public class GenricDemo {

	public static void genericExp() {
		Generic<Integer> iob = new Generic<Integer>(10);
		Generic<String> sob = new Generic<>("str");
		Generic<GenricDemo> gob = new Generic<GenricDemo>(new GenricDemo());
		System.out.println(iob + "\n" + sob + "\n" + gob + "\n\n\n");

		Integer i = iob.getInstance();
		String s = sob.getInstance();
		GenricDemo ob = gob.getInstance();

		System.out.println(i + "  " + s + "   " + ob);

		// iob = sob;
		//iob.setInstance("str");

	}

	
	public static void generalExp() {
		General iob = new General(10);
		General sob = new General("str");
		General gob = new General(new GenricDemo());

		System.out.println(iob + "\n" + sob + "\n" + gob + "\n\n\n");

		Integer i = (Integer) iob.getInstance();
		String s = (String) sob.getInstance();
		GenricDemo ob = (GenricDemo) gob.getInstance();

		System.out.println(i + "  " + s + "   " + ob);

		iob = sob;
		i = (Integer) iob.getInstance();

	}
	
	
	//Generic support non generic
	public static void generalExp2() {
		Generic iob = new Generic(10);
		iob.setInstance("str");
	}
	
	

	public static void main(String[] args) {
		genericExp();
	}

}
