package com.easylearning;

import java.util.ArrayList;
import java.util.Collections;
import java.util.Comparator;
import java.util.Iterator;
import java.util.LinkedList;
import java.util.List;
import java.util.ListIterator;
import java.util.Vector;
import static com.easylearning.Util.*;

public class ListDemo {

	public static void ListExp1() {

		List<Integer> list = new ArrayList<Integer>();
		list.add(110);
		list.add(20);
		list.add(30);
		list.add(50);

		System.out.println(list);
		display(list);

		List<String> slist = new ArrayList<String>();
		slist.add("carrot");
		slist.add("mango");
		slist.add("apple");
		slist.add("pineapple");
		slist.add("apple");

		display1(slist);

	}

	public static void display2(List<?> list) {
		ListIterator<?> itr = list.listIterator();
		while (itr.hasNext()) {
			System.out.println(itr.next());
		}
		System.out.println("------------------------------------------\n");
	}

	public static void display1(List<?> list) {
		Iterator<?> itr = list.iterator();
		while (itr.hasNext()) {
			System.out.println(itr.next());
		}
		System.out.println("------------------------------------------\n");
	}

	public static void display(List<?> list) {
		for (Object i : list) {
			System.out.println(i);
		}
		System.out.println("------------------------------------------\n");
	}

	public static void exp2() {
		List<String> fruits = new ArrayList<String>();
		fruits.add("carrot");
		fruits.add("mango");
		fruits.add("grapes");
		fruits.add("guava");
		fruits.add("plum");
		fruits.add("apple");
		fruits.add("pineapple");
		fruits.add("apple");

		removeFruit(fruits, "apple");
		display1(fruits);
	}

	public static void removeFruit(List<String> fruits, String fruit) {
		/*
		 * for(String s:fruits) { if(s.equals(fruit)) { fruits.remove(s); } }
		 */

		Iterator<String> itr = fruits.iterator();
		while (itr.hasNext()) {
			if (itr.next().equals(fruit)) {
				itr.remove();
			}
		}
	}

	public static void removeFruit1(List<String> fruits, String fruit) {
		for (int i = 0; i < fruits.size(); i++) {
			if (fruits.get(i).equals(fruit)) {
				fruits.remove(i);
			}
		}
	}

	public static void exp3() {
		List<Integer> ilist = getIntegerList();
		System.out.println(ilist);
		Collections.sort(ilist, Collections.reverseOrder());
		System.out.println("After sorting integer list: ");
		System.out.println(ilist);

		printLine();

		List<String> slist = getStringList();
		System.out.println(slist);
		Collections.sort(slist);
		System.out.println("After sorting string list: ");
		System.out.println(slist);

		printLine();

		List<Employee> empList = getEmpList();
		display(empList);
		Collections.sort(empList);
		System.out.println("After sorting emp list: ");
		display(empList);

		printLine();

		Collections.sort(empList, new EmployeeSalaryCompartor());
		System.out.println("After sorting emp list by salary: ");
		display(empList);

		printLine();

		Collections.sort(empList, new Comparator<Employee>() {

			@Override
			public int compare(Employee o1, Employee o2) {

				return o1.getName().compareTo(o2.getName());
			}
			
		});
		System.out.println("After sorting emp list by name: ");
		display(empList);
	}

	public static void main(String[] args) {
		exp3();
	}

	public static void printLine() {
		System.out.println("___________________________________________________\n");
	}

}
