
public class Date {

	// object members or object instance members or object properties
	int dd;
	int mm;
	int yy;

	// method or object behavior
	void init(int d, int m, int y) {
		dd = d;
		mm = m;
		yy = y;
	}

	// method or object behavior
	void display() {
		System.out.println(dd + "/" + mm + "/" + yy);
	}

}
