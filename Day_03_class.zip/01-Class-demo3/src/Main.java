
public class Main {

	public static void main(String[] args) {
		
		Date d1 = new Date(2,2,2022);
		Date d2 = new Date(2,2,2022);
		
		
		Date d3 = new Date();
		d3.display();

		
		
		
	}

}
