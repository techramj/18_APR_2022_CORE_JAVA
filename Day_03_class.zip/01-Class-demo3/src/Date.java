
public class Date {

	private int dd;
	private int mm;
	private int yy;

	// constructor
	public Date() {
		this(1, 1, 2001);
	}

	/// parameterized constructor
	public Date(int dd, int mm, int yy) {
		this.dd = dd;
		this.mm = mm;
		this.yy = yy;
	}

	public void display() {
		System.out.println(dd + "-" + mm + "-" + yy);
	}

	public void setMonth(int m) {
		mm = m;
	}

	public int getYear() {
		return yy;
	}

	public void foo() {
		System.out.println(this);
	}

}
