
public class Date {

	// object members or object instance members or object properties
	private int dd;
	private int mm;
	private int yy;

	// method or object behavior
	public void init(int d, int m, int y) {
		dd = d;
		mm = m;
		yy = y;
	}

	// method or object behavior
	public void display() {
		System.out.println(dd + "/" + mm + "/" + yy);
	}

	//setter 
	public void setMonth(int m) {
		if (m < 0) {
			mm = 1;
		} else if (mm > 12) {
			mm = 12;
		}
		mm = m;
	}

	
	//getter method
	public int getYear() {
		return yy;
	}
	
	public int getMonth() {
		return mm;
	}

}


