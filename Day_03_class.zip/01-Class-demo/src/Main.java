
public class Main {
	
	public static void main(String[] args) {
		int a=10;
		int b;				//variable cannot be used, if it is not initalized
		Date ob ;   //ob is reference
		ob = new Date();
		
		
		ob.display();
		
		
		Date ob2 = new Date();
		/*
		ob2.dd = 20;
		ob2.mm=4;
		ob2.yy=2022;
		*/
		ob2.init(20, 4, 2022);
		ob2.display();
		
		//change the month
		//ob2.mm=11;
		ob2.setMonth(-11);
		ob2.display();
		
		//display year
		//System.out.println("year: "+ob2.yy);
		System.out.println("year: "+ob2.getYear());
		
		
		
	}

}
