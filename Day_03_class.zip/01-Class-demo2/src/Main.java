
public class Main {

	public static void main(String[] args) {
		
		Date ob1 = new Date();
		ob1.display();
		
		//Date ob2 = new Date(2,2,2022);
		//ob2.display();

		
		
		
	}

}
