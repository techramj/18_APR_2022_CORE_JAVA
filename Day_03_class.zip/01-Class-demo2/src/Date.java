
public class Date {

	private int dd;
	private int mm;
	private int yy;

	// constructor
	public Date() {
		System.out.println("default constructor called");
		dd = 1;
		mm = 1;
		yy = 2001;
	}

	/// parameterized constructor
	public Date(int d, int m, int y) {
		System.out.println("Parameterized constructor called");
		dd = d;
		mm = m;
		yy = y;
	}

	public void display() {
		System.out.println(dd + "/" + mm + "/" + yy);
	}

	public void setMonth(int m) {
		mm = m;
	}

	public int getYear() {
		return yy;
	}

}
