import java.awt.Color;
import java.awt.Graphics;

import javax.swing.JFrame;

public class MyFrame1 extends JFrame implements Runnable {

	int rx, gx, bx;

	public MyFrame1() {

		rx = gx = bx = 50;

		this.setVisible(true);
		this.setSize(1000, 500);
		this.setDefaultCloseOperation(JFrame.EXIT_ON_CLOSE);
	}

	@Override
	public void paint(Graphics g) {

		// super.paint(g);
		g.setColor(Color.red);
		g.fillOval(rx, 50, 20, 20);

		g.setColor(Color.green);
		g.fillOval(gx, 200, 20, 20);

		g.setColor(Color.blue);
		g.fillOval(bx, 350, 20, 20);
	}

	@Override
	public void run() {
		while (true) {
			try {
				if (Thread.currentThread().getName().equals("red")) {
					rx++;
					Thread.sleep(20);
					if (rx % 200 == 0) {
						synchronized (this) {
							wait();
						}
					}

				}
				if (Thread.currentThread().getName().equals("green")) {
					gx++;
					Thread.sleep(50);
					if (gx % 200 == 0) {
						synchronized (this) {
							wait();
						}
					}
				}
				if (Thread.currentThread().getName().equals("blue")) {
					bx++;
					Thread.sleep(100);
					if (bx % 200 == 0) {
						synchronized (this) {
							notifyAll();
						}
					}
				}
			} catch (Exception e) {
				e.printStackTrace();
			}
			repaint();
		}

	}

	public static void main(String[] args) {
		MyFrame1 frame = new MyFrame1();

		Thread t1 = new Thread(frame, "red");
		Thread t2 = new Thread(frame, "green");
		Thread t3 = new Thread(frame, "blue");

		t1.start();
		t2.start();
		t3.start();
	}

}
