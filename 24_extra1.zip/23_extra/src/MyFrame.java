import java.awt.Container;
import java.awt.FlowLayout;
import java.awt.event.ActionEvent;
import java.awt.event.ActionListener;

import javax.swing.JButton;
import javax.swing.JFrame;
import javax.swing.JLabel;
import javax.swing.JPasswordField;
import javax.swing.JTextField;

public class MyFrame extends JFrame {
	
	JLabel lbUser;
	JLabel lbPassword;
	JTextField txUser;
	JPasswordField txPassword;
	JButton bSubmit, bReset;
	
	public MyFrame() {
		
		lbUser = new JLabel("Username: ");
		lbPassword = new JLabel("Password");
		txUser = new JTextField(20);
		txPassword= new JPasswordField(20);
		bSubmit = new JButton("Submit");
		bReset = new JButton("Reset");
		
		this.setLayout(new FlowLayout());
		Container pane = this.getContentPane();
		
		pane.add(lbUser);
		pane.add(txUser);
		
		pane.add(lbPassword);
		pane.add(txPassword);
		
		pane.add(bSubmit);
		pane.add(bReset);
		
	    bSubmit.addActionListener(new X());
	    bReset.addActionListener(new X());
		
		this.setVisible(true);
		this.setSize(800,400);
		this.setDefaultCloseOperation(JFrame.EXIT_ON_CLOSE);
	}
	
	
	class X implements ActionListener{

		@Override
		public void actionPerformed(ActionEvent e) {
			if(e.getActionCommand().equalsIgnoreCase("reset")) {
				txPassword.setText("");
				txUser.setText("");
			}else{
				String username=txUser.getText();
				String password= txPassword.getText();
				
				System.out.println(username+"  "+password);
			}
			
			
			
		}
		
	}
	
	
	
	
	public static void main(String[] args) {
		MyFrame frame= new MyFrame();
	
	}

}
