import java.awt.BorderLayout;
import java.awt.Color;
import java.awt.event.KeyEvent;
import java.awt.event.KeyListener;
import java.io.DataInputStream;
import java.io.DataOutputStream;
import java.io.IOException;
import java.net.ServerSocket;
import java.net.Socket;

import javax.swing.JFrame;
import javax.swing.JTextArea;
import javax.swing.JTextField;

public class MyServer extends JFrame implements KeyListener {

	JTextArea area;
	JTextField txField;
	ServerSocket ss;
	Socket socket;
	DataOutputStream dos;
	DataInputStream dis;
	
	
	public void startServer() throws IOException {
		ss = new ServerSocket(5000);
		System.out.println("Server created with port 5000");
		System.out.println("marking a call to client.....");
		socket = ss.accept();
		dis = new DataInputStream(socket.getInputStream());
		dos = new DataOutputStream(socket.getOutputStream());
	}

	public MyServer() {
		super("Server");
		
		try {
			startServer();
		} catch (IOException e) {
			e.printStackTrace();
		}
		
		area = new JTextArea();
		txField = new JTextField();

		area.setDisabledTextColor(Color.black);

		this.getContentPane().add(area, BorderLayout.CENTER);
		this.getContentPane().add(txField, BorderLayout.SOUTH);

		txField.addKeyListener(this);

		this.setVisible(true);
		this.setSize(400, 300);
		this.setDefaultCloseOperation(JFrame.EXIT_ON_CLOSE);
		
	}
	
	public void chat() throws IOException {
		while(true) {
			String str=dis.readUTF();
			area.append("Client "+str);
			area.append("\n");
		}
	}


	@Override
	public void keyTyped(KeyEvent e) {

	}

	@Override
	public void keyPressed(KeyEvent e) {

	}

	@Override
	public void keyReleased(KeyEvent e) {

		// System.out.println(e.getKeyCode()+" "+e.getKeyChar()+" "+e.getID());
		if (e.getKeyCode() == 10) {
			String text = txField.getText();
			txField.setText("");
			area.append("Server:  ");
			area.append(text + "\n");
			try {
				dos.writeUTF(text);
			} catch (IOException e1) {
				// TODO Auto-generated catch block
				e1.printStackTrace();
			}
		}

	}
	
	public static void main(String[] args) {
		try {
			new MyServer().chat();
		} catch (IOException e) {
			// TODO Auto-generated catch block
			e.printStackTrace();
		}
	}


}
