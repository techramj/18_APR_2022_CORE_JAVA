import java.awt.BorderLayout;
import java.awt.Color;
import java.awt.event.KeyEvent;
import java.awt.event.KeyListener;
import java.io.DataInputStream;
import java.io.DataOutputStream;
import java.io.IOException;
import java.net.InetAddress;
import java.net.Socket;
import java.net.UnknownHostException;

import javax.swing.JFrame;
import javax.swing.JTextArea;
import javax.swing.JTextField;

public class MyClient extends JFrame implements KeyListener {

	JTextArea area;
	JTextField txField;
	Socket socket;
	DataOutputStream dos;
	DataInputStream dis;

	public void acceptCall() throws UnknownHostException, IOException {
		socket = new Socket(InetAddress.getLocalHost(), 5000);
		System.out.println("call accepted!!!!!!");
		dis = new DataInputStream(socket.getInputStream());
		dos = new DataOutputStream(socket.getOutputStream());
	}

	public MyClient() {
		super("Client");

		try {
			acceptCall();
		} catch (UnknownHostException e) {
			e.printStackTrace();
		} catch (IOException e) {
			e.printStackTrace();
		}

		area = new JTextArea();
		txField = new JTextField();

		area.setDisabledTextColor(Color.black);

		this.getContentPane().add(area, BorderLayout.CENTER);
		this.getContentPane().add(txField, BorderLayout.SOUTH);

		txField.addKeyListener(this);

		this.setVisible(true);
		this.setSize(400, 300);
		this.setDefaultCloseOperation(JFrame.EXIT_ON_CLOSE);
	}

	public void chat() throws IOException {
		while (true) {
			String str = dis.readUTF();
			area.append("Server " + str);
			area.append("\n");
		}
	}

	@Override
	public void keyTyped(KeyEvent e) {
	}

	@Override
	public void keyPressed(KeyEvent e) {
	}

	@Override
	public void keyReleased(KeyEvent e) {

		if (e.getKeyCode() == 10) {
			String text = txField.getText();
			txField.setText("");
			area.append("Client:  ");
			area.append(text + "\n");

			try {
				dos.writeUTF(text);
			} catch (IOException e1) {
				// TODO Auto-generated catch block
				e1.printStackTrace();
			}
		}

	}

	public static void main(String[] args) {
		try {
			new MyClient().chat();
		} catch (IOException e) {
			// TODO Auto-generated catch block
			e.printStackTrace();
		}
	}

}
