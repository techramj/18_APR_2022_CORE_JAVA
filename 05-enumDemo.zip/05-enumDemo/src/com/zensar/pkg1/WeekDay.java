package com.zensar.pkg1;

public class WeekDay {
	
	public static final WeekDay SUNDAY = new WeekDay("SUNDAY");
	public static final WeekDay MONDAY = new WeekDay("SUNDAY");
	public static final WeekDay TUESDAY = new WeekDay("SUNDAY");
	public static final WeekDay WEDNESDAY = new WeekDay("SUNDAY");
	public static final WeekDay THURSDAY = new WeekDay("SUNDAY");
	public static final WeekDay FRIDAY = new WeekDay("SUNDAY");
	public static final WeekDay SATURDAY = new WeekDay("SUNDAY");

	private String day;
	private int dd;
	
	private WeekDay(String day) {
		this.day = day;
	}

	public String getDay() {
		return day;
	}

	public void setDay(String day) {
		this.day = day;
	}

}
