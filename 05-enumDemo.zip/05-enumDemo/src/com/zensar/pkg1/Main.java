package com.zensar.pkg1;

public class Main {
	
	public static void main(String[] args) {		
		WeekDay day5 = WeekDay.SUNDAY;
		
		String day ="sunday";
		

		
		
		
	}

}
