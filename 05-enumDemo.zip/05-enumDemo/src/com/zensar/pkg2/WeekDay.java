package com.zensar.pkg2;

public enum WeekDay {
	
	MONDAY(2), TUESDAY(3), THURSDAY(5), FRIDAY(6), SATURDAY(7), SUNDAY(1), WEDNESDAY(4);
	
	int day;
	
	private WeekDay(int day){
		this.day = day;
	}

	public static WeekDay getDay(String day) {
		if(day == null) {
			return null;
		}
		for(WeekDay d: WeekDay.values()) {
			if(day.equalsIgnoreCase(d.name()) || d.name().contains(day.toUpperCase()) ) {
				return d;
			}
		}
		return null;
	}
	

}
