package com.zensar.pkg2;


public class Date {

	private int dd;
	private Month mm;
	private int yy;
	
	
	public Date() {
		
	}

	public Date(int dd, int mm, int yy) {
		this.dd = dd;
		this.mm = Month.month(yy);
		this.yy = yy;
	}

	public int getDd() {
		return dd;
	}

	public void setDd(int dd) {
		this.dd = dd;
	}

	public int getMm() {
		return mm.getMonth();
	}

	public void setMm(int mm) {
		this.mm = Month.month(mm);
	}

	public int getYy() {
		return yy;
	}

	public void setYy(int yy) {
		this.yy = yy;
	}
	
	
	public boolean isLeapYear() {
		return (yy%400==0 || (yy%100 !=0 && yy%4==0));
	}
	

	public static boolean isLeapYear(int year) {
		return (year%400==0 || (year%100 !=0 && year%4==0));
	}
	

	
}
