package com.zensar.pkg2;

public class EnumDemo {
	
	public static void main(String[] args) {
		WeekDay sun = WeekDay.SUNDAY;
		System.out.println(sun.ordinal());
		System.out.println(sun.toString());
		System.out.println(sun.name());
		
		WeekDay[] days = WeekDay.values();
		for(WeekDay d: days) {
			System.out.println(d.ordinal()+"  "+d.name());
		}
		
	
		WeekDay d1 = WeekDay.getDay("Holiday");
		System.out.println(d1);
		
		
	}

}
