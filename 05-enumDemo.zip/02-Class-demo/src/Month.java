
public enum Month {
	JAN(1,31),
	FEB(2,28),
	MAR(3,31),
	APR(4,30),
	MAY(5,31),
	JUN(5,30),
	JUL(5,31),
	AUG(5,31),
	SEP(5,30),
	OCT(5,31),
	NOV(5,30),
	DEC(5,31);
	
	int month;
	int noOfDay;
	
	private Month(int month, int noOfDay) {
		this.month = month;
		this.noOfDay = noOfDay;
	}
	
	public int getMonth() {
		return month;
	}
	
	public int getNoOfDay() {
		return noOfDay;
	}
	
	public int getNoOfDay(boolean isLeapYear) {
		if(isLeapYear && month==2) {
			return noOfDay+1;
		}
		return noOfDay;
	}
	
	public static Month month(int month) {
		
		for(Month m:Month.values()) {
			if(m.getMonth() == month) {
				return m;
			}
		}
		return null;
	}


}
