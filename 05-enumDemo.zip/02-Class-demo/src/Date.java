
public class Date {

	private int dd;
	private int mm;
	private int yy;
	
	private final static int[] lastDays = new int[] {31,28,31,30,31,30,31,31,30,31,30,31};
	
	public Date() {
		
	}

	public Date(int dd, int mm, int yy) {
		this.dd = dd;
		this.mm = mm;
		this.yy = yy;
	}

	public int getDd() {
		return dd;
	}

	public void setDd(int dd) {
		this.dd = dd;
	}

	public int getMm() {
		return mm;
	}

	public void setMm(int mm) {
		this.mm = mm;
	}

	public int getYy() {
		return yy;
	}

	public void setYy(int yy) {
		this.yy = yy;
	}
	

	
	
	//validation if dd,mm,yy is invalid then set the default value 
	// dd=1  mm=1, yy=2001
	
	//31,4,2019  => 1,4,2019
	//29,2,2001
	
	public boolean isLeapYear() {
		return (yy%400==0 || (yy%100 !=0 && yy%4==0));
	}
	
	//utility method
	public static boolean isLeapYear(int year) {
		return (year%400==0 || (year%100 !=0 && year%4==0));
	}
	
	public int lastDay() {
		if(mm==2 && isLeapYear()) {
			return 29;
		}
		return lastDays[mm-1];
	}
	
	public static int lastDay(int month, boolean isLeapYear) {
		if(month==2 && isLeapYear) {
			return 29;
		}
		return lastDays[month-1];
	}
	
	
	
	public boolean isLastDay() {
		return dd== lastDay();
	}
	
	public Date addDays(int noOfDays) {
		
		int approxNoOFMonth = noOfDays/30;  //5 , 32
		int lastday = lastDay();
		
		if(approxNoOFMonth ==0) {
			dd = dd+noOfDays;
			if(dd> lastday) {
				mm = mm+1;
				if(mm>12) {
					yy = yy+1;
					mm = 1;
				}
				dd = dd-lastday;
				
			}
		}
		

		for(int i=1;i<=approxNoOFMonth;i++) {
		    int ld = lastDay();
		    mm = mm+1;
		    if(mm>12) {
		    	yy=yy+1;
		    	mm=1;
		    }
		    noOfDays = noOfDays-ld;
		}
		
		dd = dd+noOfDays;
		if(dd> lastday) {
			mm = mm+1;
			if(mm>12) {
				yy = yy+1;
				mm = 1;
			}
			dd = dd-lastday;
			
		}
		
		
		return this;
	}
	
	public Date addMonths(int noOfMonths) {
		int year = noOfMonths/12;
		int month = noOfMonths%12;
		
		boolean isLastDay = isLastDay();
		
		yy= yy+year;
		mm= mm +month;
		
		if(isLastDay) {
			dd = lastDay();
		}
		
		
		return this;  //29-2-2020  => 28-2-2021  31-5-2020  -> 30-6-2020
	}
	
	public Date addYear(int years) {
		return null;
	}

	@Override
	public String toString() {
		return "Date [dd=" + dd + ", mm=" + mm + ", yy=" + yy + "]";
	}
	
	
	
}
