package com.easylearning;

import java.util.Objects;

import com.easylearning.main.Main;

public class Employee implements Insurance, Printable, Cloneable {

	int id;
	protected String name;
	private double salary;

	public Employee() {
		super();
		// System.out.println("default Emp contructor called");
	}

	public Employee(int id, String name, double salary) {
		// System.out.println("parameterized Emp contructor called");
		this.id = id;
		this.name = name;
		this.salary = salary;
	}

	public int getId() {
		return id;
	}

	public void setId(int id) {
		this.id = id;
	}

	public String getName() {
		return name;
	}

	public void setName(String name) {
		this.name = name;
	}

	public double getSalary() {
		return salary;
	}

	public void setSalary(double salary) {
		this.salary = salary;
	}

	public double computeNetSalary() {
		// System.out.println("inside Employee computeNetSalary");
		return salary;
	}

	@Override
	public String toString() {
		return "Employee [id=" + id + ", name=" + name + ", salary=" + salary + "]";
	}

	@Override
	public int hashCode() {
		return Objects.hash(id, name, salary);
	}

	@Override
	public boolean equals(Object obj) {
		if (this == obj)
			return true;
		if (!(obj instanceof Employee)) {
			return false;
		}
		Employee other = (Employee) obj;
		return id == other.id && Objects.equals(name, other.name)
				&& Double.doubleToLongBits(salary) == Double.doubleToLongBits(other.salary);
	}

	/*
	 * @Override public boolean equals(Object obj) { if(this == obj) { return true;
	 * }
	 * 
	 * if(!(obj instanceof Employee)) { return false; } Employee e = (Employee)obj;
	 * 
	 * return this.id== e.id && this.salary== e.salary && this.name.equals(e.name);
	 * 
	 * }
	 * 
	 * @Override public int hashCode() { //return (id+name+salary).hashCode();
	 * return Objects.hash(id,name,salary);
	 * 
	 * }
	 */
	
	public Employee getInstance() {
		return new Employee(0,"No Name",0);
	}
	
	@Override
	public void getInsurance() {
		// TODO Auto-generated method stub
		
	}

	@Override
	public void print() {
		System.out.println("Id: "+getId());
		System.out.println("Name:  "+getName());
		System.out.println("Net salary: "+computeNetSalary());
		Main.printLine();
		
	}
	
	public Employee cloneObject() {
		Employee emp= new Employee();
		emp.setId(this.getId());
		emp.setName(this.getName());
		emp.setSalary(this.getSalary());
		
		return emp;
	}
	
	@Override
	public Employee clone() throws CloneNotSupportedException {
		return (Employee)super.clone();
	}

}
