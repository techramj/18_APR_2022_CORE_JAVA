package com.easylearning.main;

import com.easylearning.Employee;
import com.easylearning.SalesPerson;
import com.easylearning.pkg1.Manager;

public class Main3 {

	public static void main(String[] args) {
		Employee emp1 = new Employee(1, "Jack", 1000);
		// Manager mgr = emp1; //sub class cannot refer to suber class

		Manager mgr = new Manager(2, "Sam", 20000, 2);
		Employee emp2 = mgr;
		
		Manager mgr2 = (Manager) mgr.getInstance();

		display(new Employee(11, "Jessica", 1000));
		display(new SalesPerson(2, "Jenny", 2000, 20000, 2));
		display(new Manager(3, "Julie", 3000, 2));
		

	}

	public static void display(Employee emp) {

		if (emp instanceof Manager) {
			System.out.println("Bonus: " + ((Manager) emp).getBonus());
		} else if (emp instanceof SalesPerson) {
			System.out.println("Comm: " + ((SalesPerson) emp).computeCommission());
		}
		
		
		System.out.println("Details: " + emp);
		if(emp instanceof Employee){
		System.out.println("Net salary: " + ((Employee)emp).computeNetSalary());
		}

		Main.printLine();
	}

}
