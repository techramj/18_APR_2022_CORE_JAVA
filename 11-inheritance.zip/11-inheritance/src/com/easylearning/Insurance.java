package com.easylearning;

public interface Insurance {
	
	public void getInsurance();

}
