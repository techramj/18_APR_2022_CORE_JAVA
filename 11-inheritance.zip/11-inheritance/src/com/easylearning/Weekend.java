package com.easylearning;

public interface Weekend {
	
  int MONDAY =1;
  
  double PI = 3.14;
  double PLANK_CONST = 3.11;
  double LOG_E = 0;
  
 

}
