package com.easylearning;

public class Bike implements Cloneable {

	private String name;

	private Engine engine;

	public Bike() {

	}

	public Bike(String name, Engine engine) {
		super();
		this.name = name;
		this.engine = engine;
	}

	public String getName() {
		return name;
	}

	public void setName(String name) {
		this.name = name;
	}

	public Engine getEngine() {
		return engine;
	}

	public void setEngine(Engine engine) {
		this.engine = engine;
	}

	@Override
	public String toString() {
		return "Bike [name=" + name + ", engine=" + engine + "]";
	}
	
	@Override
	public Bike clone() throws CloneNotSupportedException {
		Bike bike= (Bike) super.clone();
		bike.setEngine((Engine)bike.getEngine().clone());
		return bike;
	}

}
