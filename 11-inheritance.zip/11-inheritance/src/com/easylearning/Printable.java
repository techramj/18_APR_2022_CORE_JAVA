package com.easylearning;

public interface Printable {
	
	public void print();
	

}
