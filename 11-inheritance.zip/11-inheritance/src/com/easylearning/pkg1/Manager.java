package com.easylearning.pkg1;

import com.easylearning.Employee;

public class Manager extends Employee {
	
	protected int noOfSubordinate;
	
	public Manager() {
		// TODO Auto-generated constructor stub
	}
	
	public Manager(int id, String name, double salary, int noOfSubordinate) {
		super(id, name, salary);
		this.noOfSubordinate = noOfSubordinate;
	}

	
	public double getBonus() {
		return noOfSubordinate*500;
	}

	
	public String toString() {
		return super.toString()+"  Manager [noOfSubordinate=" + noOfSubordinate + "]";
	}
	
	
	public double computeNetSalary() {
		// TODO Auto-generated method stub
		return super.computeNetSalary()+getBonus();
	}
	
	
	public Manager getInstance() {
		
		return new Manager();
	}
	
	

}
