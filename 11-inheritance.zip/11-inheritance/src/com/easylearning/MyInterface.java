package com.easylearning;

public interface MyInterface {

	int a = 10; // public static final
	// public static final a=10;
	
	void foo();  //=> public abstract void foo();

}

abstract class A1 {
	int a = 10; // access specifier = default

	public void foo() {

	}
	
	 protected abstract void foo1();

}
