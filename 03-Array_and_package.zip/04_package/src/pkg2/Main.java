package pkg2;

import pkg1.Employee;
import pkg1.Student;


public class Main {
	
	public static void main(java.lang.String[] args) {
		Employee emp1 = new Employee();
		
		pkg3.Employee emp2 = new pkg3.Employee();
		
		System.out.println("");
		
		Student stud1 = new Student();
		
		Student stud2 = new Student();
		
	}

}
