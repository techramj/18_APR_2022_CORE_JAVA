package pkg1;

public class Main {
	
	public static void main(String[] args)  {
		

		Employee emp1 = new Employee("Jack",1000);
		Employee emp2 = new Employee("John",2000);
		Employee emp3 = new Employee();
		new Employee();
		System.out.println(emp1);
		System.out.println(emp2);
		
		

		System.out.println("Number of Employees: "+Employee.noOfEmployees());
		
	}

}
