package pkg1;

public class Student {

	// non static variable or data member or instance member or object properties
	private int rollno;
	private String name;
	private String course;

	// static variable or class member
	private static String projector;
	private static String trainerName;

	public static void setTrainerName(String name) {
		trainerName = name;
	}

}
