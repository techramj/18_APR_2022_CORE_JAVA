
public class Array2dDemo {
	
	public static void main(String[] args) {
		int[][] arr;
		arr=new int[2][3];
		
		int[][] barr = {{1,2,3},{10,20},{100,200,300,400}};
		
		int[][] carr= new int[4][];
		carr[0] = new int[] {11,22};
		carr[1] = new int[] {111,222,333};
		carr[2] =new int[] {10,20,30,40,50};
		carr[3] = new int[1];
		
		display(arr);
		display(barr);
		display(carr);
		
	}
	
	public static void display(int[][] arr) {
		for(int[] ar  :arr) {
			for(int a:ar) {
				System.out.print(a+" ");
			}
			System.out.println();
		}
		System.out.println("----------------------------");
	}
	
	public static void display1(int[][] arr) {
		for(int i=0;i<arr.length;i++) {
			for(int j=0;j<arr[i].length;j++) {
				System.out.print(arr[i][j]+"  ");
			}
			System.out.println();
		}
		System.out.println("-------------------------------------------------------");
	}

}
